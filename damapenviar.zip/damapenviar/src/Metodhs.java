/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.awt.Color;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.YES_OPTION;

/**
 *
 * @author Liz I= coluna J=linha
 */
public class Metodhs extends Dama3 {

    static int contadama1 = 0;
    static int contadama22 = 0;
    static int contabranco2 = 0;
    static int contapreto2 = 0;
    static int i2 = 0;
    static int j2 = 0;
    static JButton botaoclick;
    static JButton outrobotao;
    static JButton outrobotao2;
    static boolean verdinha = false;
    static boolean comeu = false;
    static JButton[] comebtn = new JButton[20];
    static JButton[] comebtn2 = new JButton[20];
    static JButton[] comebtn3 = new JButton[20];
    static JButton[] comebtn4 = new JButton[20];
    static JButton[] comidadama = new JButton[20];
    static JButton[] comidadama2 = new JButton[20];
    static JButton[] comidadama3 = new JButton[20];
    static JButton[] comidadama4 = new JButton[20];

    static int vez = 0;
    static int vez2 = 0;
    static int tm[] = new int[8];
    static boolean podecomer = false;
    static boolean comecome = false;
    static boolean comecome2 = false;
    static boolean comeudama = false;
    static int g = 0;
    static int g2 = 0;
    static int g3 = 0;
    static int g4 = 0;
    static int i3 = 0;
    static int j3 = 0;
    static int contadama = 0;
    static int contadama2 = 0;
    static int contajog = 0;
    static int contabranco = 0;
    static int contapreto = 0;

    static public void changecolor(int i, int j) {
        vitoria();
        contapreto = 0;
        contabranco = 0;
        contadama = 0;
        contadama2 = 0;
        g = 0;
        g2 = 0;
        g3 = 0;
        g4 = 0;
        int d = 1;
        int linha = 0;
        if ((button[i][j].getIcon() == damabranca) || (button[i][j].getIcon() == damapreta)) {

            botaoclick = Dama3.button[i][j];

            if (((vez % 2 == 0) && (botaoclick.getIcon() == damabranca)) || ((vez % 2 == 1) && (botaoclick.getIcon() == damapreta))) { //checa se a peca eh dama
                i3 = i;
                j3 = j;
                int v;
                boolean pare = false;
                boolean pare2 = false;
                boolean pare3 = false;
                boolean pare4 = false;

                for (v = 1; v < 8; v++) { //serve pra ir incrementando ou decrementando as posicoes pra checar se ta vazio
                    if (((i + v) <= 7) && ((j + v) <= 7)) {
                        if (button[i + v][j + v].getIcon() == vazio) {
                            if (pare == false) {
                                button[i + v][j + v].setIcon(verde);
                            }
                        } else if (((button[i + v][j + v].getIcon() == branco)||(button[i + v][j + v].getIcon() == damabranca)) && (button[i][j].getIcon() == damabranca)) {
                            pare = true;
                             System.out.print("yes");
                        } else if (((button[i + v][j + v].getIcon() == Preto)||(button[i + v][j + v].getIcon() == damapreta)) && (button[i][j].getIcon() == damapreta)) {
                            pare = true;
                            System.out.print("sim");
                        }
                        if (((j + v + 1) <= 7) && ((i + v + 1) <= 7)) {
                            if (((button[i + v][j + v].getIcon() == button[i + v + 1][j + v + 1].getIcon()) || ((button[i + v][j + v].getIcon() == Preto) && (button[i + v + 1][j + v + 1].getIcon() == branco)) || ((button[i + v][j + v].getIcon() == branco) && (button[i + v + 1][j + v + 1].getIcon() == Preto)))) {
                                pare = true;
                            } else if ((botaoclick.getIcon() == damabranca) && ((button[i + v][j + v].getIcon() == Preto) || (button[i + v][j + v].getIcon() == damapreta))) {
                                comeudama = true;
                                comidadama[g] = button[i + v][j + v];
                                g++;

                            } else if ((botaoclick.getIcon() == damapreta) && ((button[i + v][j + v].getIcon() == branco) || (button[i + v][j + v].getIcon() == damabranca))) {
                                comeudama = true;
                                comidadama[g] = button[i + v][j + v];
                                g++;

                            }
                        }

                    }

                    if (((i - v) >= 0) && ((j + v) <= 7)) {
                        if (button[i - v][j + v].getIcon() == vazio) {
                            if (pare2 == false) {

                                button[i - v][j + v].setIcon(verde);
                            }
                        } else if ((button[i - v][j + v].getIcon() == branco) && (button[i][j].getIcon() == damabranca)) {
                            pare2 = true;
                        } else if ((button[i - v][j + v].getIcon() == Preto) && (button[i][j].getIcon() == damapreta)) {
                            pare2 = true;
                        }
                        if (((j + v + 1) <= 7) && ((i - v - 1) >= 0)) {
                            if ((button[i - v][j + v].getIcon() == button[i - v - 1][j + v + 1].getIcon()) || ((button[i - v][j + v].getIcon() == Preto) && (button[i - v - 1][j + v + 1].getIcon() == branco)) || ((button[i - v][j + v].getIcon() == branco) && (button[i - v - 1][j + v + 1].getIcon() == Preto))) {
                                pare2 = true;
                            } else if ((botaoclick.getIcon() == damabranca) && ((button[i - v][j + v].getIcon() == Preto) || (button[i - v][j + v].getIcon() == damapreta))) {
                                comeudama = true;
                                comidadama2[g2] = button[i - v][j + v];
                                g2++;
                            } else if ((botaoclick.getIcon() == damapreta) && ((button[i - v][j + v].getIcon() == branco) || (button[i - v][j + v].getIcon() == damabranca))) {
                                comeudama = true;
                                comidadama2[g2] = button[i - v][j + v];
                                g2++;
                            }
                        }

                    }
                    if (((i + v) <= 7) && ((j - v) >= 0)) {
                        if (button[i + v][j - v].getIcon() == vazio) {
                            if (pare3 == false) {
                                button[i + v][j - v].setIcon(verde);
                            }
                        } else if ((button[i + v][j - v].getIcon() == branco) && (button[i][j].getIcon() == damabranca)) {
                            pare3 = true;
                        } else if ((button[i + v][j - v].getIcon() == Preto) && (button[i][j].getIcon() == damapreta)) {
                            pare3 = true;
                        }
                        if (((j - v - 1) >= 0) && ((i + v + 1) <= 7)) {
                            if ((button[i + v][j - v].getIcon() == button[i + v + 1][j - v - 1].getIcon()) || ((button[i + v][j - v].getIcon() == Preto) && (button[i + v + 1][j - v - 1].getIcon() == branco)) || ((button[i + v][j - v].getIcon() == branco) && (button[i + v + 1][j - v - 1].getIcon() == Preto))) {
                                pare3 = true;
                            } else if ((botaoclick.getIcon() == damabranca) && ((button[i + v][j - v].getIcon() == Preto) || (button[i + v][j - v].getIcon() == damapreta))) {
                                comeudama = true;
                                comidadama3[g3] = button[i + v][j - v];
                                g3++;
                            } else if ((botaoclick.getIcon() == damapreta) && ((button[i + v][j - v].getIcon() == branco) || (button[i + v][j - v].getIcon() == damabranca))) {
                                comeudama = true;
                                comidadama3[g3] = button[i + v][j - v];
                                g3++;

                            }
                        }
                    }

                    if (((i - v) >= 0) && ((j - v) >= 0)) {
                        if (button[i - v][j - v].getIcon() == vazio) {
                            if (pare4 == false) {
                                button[i - v][j - v].setIcon(verde);
                            }
                        } else if ((button[i - v][j - v].getIcon() == branco) && (button[i][j].getIcon() == damabranca)) {
                            pare4 = true;
                        } else if ((button[i - v][j - v].getIcon() == Preto) && (button[i][j].getIcon() == damapreta)) {
                            pare4 = true;
                        }
                        if (((j - v - 1) >= 0) && ((i - v - 1) >= 0)) {
                            if ((button[i - v][j - v].getIcon() == button[i - v - 1][j - v - 1].getIcon()) || ((button[i - v][j - v].getIcon() == Preto) && (button[i - v - 1][j - v - 1].getIcon() == branco)) || ((button[i - v][j - v].getIcon() == branco) && (button[i - v - 1][j - v - 1].getIcon() == Preto))) {
                                pare4 = true;
                            } else if ((botaoclick.getIcon() == damabranca) && ((button[i - v][j - v].getIcon() == Preto) || (button[i - v][j - v].getIcon() == damapreta))) {
                                comeudama = true;
                                comidadama4[g4] = button[i - v][j - v];
                                g4++;
                            } else if ((botaoclick.getIcon() == damapreta) && ((button[i - v][j - v].getIcon() == branco) || (button[i - v][j - v].getIcon() == damabranca))) {
                                comeudama = true;
                                comidadama4[g4] = button[i - v][j - v];
                                g4++;
                            }
                        }

                    }

                }

            }
        } else if ((button[i][j].getIcon() == Dama3.Preto) || (Dama3.button[i][j].getIcon() == Dama3.branco)) {

            botaoclick = Dama3.button[i][j];

            i2 = i;
            j2 = j;
            /*Compara a imagem(icon) do botao clicado (passado por parametro) com as imagens (icons) das peça branca e preta*/

            if (Dama3.button[i][j].getIcon() == Dama3.Preto) {
                linha = j + 1;

                for (int coluna = 0; coluna < 8; coluna++) {
                    for (int linhaa = 0; linhaa < 8; linhaa++) {
                        if (button[coluna][linhaa].getIcon() == Preto) {
                            podecomer(coluna, linhaa);
                        }
                    }

                }

            } else if (Dama3.button[i][j].getIcon() == Dama3.branco) {
                linha = j - 1;
                for (int coluna2 = 0; coluna2 < 8; coluna2++) {
                    for (int linhaa2 = 0; linhaa2 < 8; linhaa2++) {
                        if (button[coluna2][linhaa2].getIcon() == branco) {
                            podecomer(coluna2, linhaa2);
                        }
                    }

                }
            }

            if (((vez % 2 == 0) && (botaoclick.getIcon() == branco)) || ((vez % 2 == 1) && (botaoclick.getIcon() == Preto))) {

                if (podecomer == false) {
                    if ((verdinha == false)) {

                        if (i == 0) {

                            if (button[i + 1][linha].getIcon() == vazio) {
                                button[i + 1][linha].setIcon(verde);
                                verdinha = true;

                            }

                        } else if (i == 7) {

                            if (button[i - 1][linha].getIcon() == vazio) {
                                button[i - 1][linha].setIcon(verde);
                                verdinha = true;

                            }
                        } else {

                            if ((Dama3.button[i - 1][linha].getIcon() == Dama3.vazio)) {

                                verdinha = true;
                                Dama3.button[i - 1][linha].setIcon(Dama3.verde);

                            }
                            if ((Dama3.button[i + 1][linha].getIcon() == Dama3.vazio)) {

                                verdinha = true;
                                Dama3.button[i + 1][linha].setIcon(Dama3.verde);

                            }

                        }

                    }

                } else {

                    comer(i, j);
                    podecomer = false;

                }

            }

        } else if ((Dama3.button[i][j].getIcon() == Dama3.verde)) {
            for (int y = 0; y < 8; y++) {
                for (int y2 = 0; y2 < 8; y2++) {

                    if (button[y][y2].getIcon() == Preto) {
                        contapreto++;

                    }
                    if (button[y][y2].getIcon() == branco) {
                        contabranco++;

                    }

                    if ((contapreto == 0) && (contabranco == 0)) {
                        if (button[y][y2].getIcon() == damapreta) {
                            contadama++;
                        }
                        if (button[y][y2].getIcon() == damabranca) {
                            contadama2++;

                        }

                    }
                    if ((contapreto == 1) && (contabranco == 0)) {
                        if (button[y][y2].getIcon() == damapreta) {
                            contadama++;
                        }
                        if (button[y][y2].getIcon() == damabranca) {
                            contadama2++;

                        }

                    }
                    if ((contapreto == 0) && (contabranco == 1)) {
                        if (button[y][y2].getIcon() == damapreta) {
                            contadama++;
                        }
                        if (button[y][y2].getIcon() == damabranca) {
                            contadama2++;

                        }

                    }

                }
            }

            //empate condições
            if ((contadama == 1) && (contadama2 == 1) && (contapreto == 0) && (contabranco == 0)) {

                contajog++;
            }
            if ((contadama == 2) && (contadama2 == 2) && (contapreto == 0) && (contabranco == 0)) {
                contajog++;
            }
            if ((((contadama == 2) && (contadama2 == 1)) || ((contadama2 == 2) && (contadama == 1))) && (contapreto == 0) && (contabranco == 0)) {
                contajog++;
            }

            if (((contadama == 1) && (contapreto == 1) && (contadama2 == 2)) || ((contadama == 2) && (contadama2 == 1) && (contabranco == 1))) {
                contajog++;
            }
            if (((contadama == 1) && (contapreto == 1) && (contadama2 == 1)) || ((contadama == 1) && (contadama2 == 1) && (contabranco == 1))) {
                contajog++;
            }

            if (contajog >= 20) {
                int resp;
                JOptionPane.showMessageDialog(null, "EMPATE");
                System.exit(0);
            }

            if ((botaoclick.getIcon() == Preto) && (j == 7)) {
                Dama3.button[i][j].setIcon(damapreta);
                btnvazio();
                verdinha = false;
                botaoclick.setIcon(Dama3.vazio);
                vez++;

            } else if ((botaoclick.getIcon() == branco) && (j == 0)) {
                Dama3.button[i][j].setIcon(damabranca);
                btnvazio();
                verdinha = false;
                botaoclick.setIcon(Dama3.vazio);
                vez++;

            } else {

                verdinha = false;
                Dama3.button[i][j].setIcon(botaoclick.getIcon());
                botaoclick.setIcon(Dama3.vazio);
                btnvazio();
                vez++;

            }

            if (comeudama) {
                if ((i3 < i) && (j3 < j)) {
                    for (int u = 0; u < comidadama.length; u++) {
                        comidadama[u].setIcon(vazio);
                        comeudama = false;
                    }

                }

                //- -
                if ((i3 > i) && (j3 > j)) {

                    for (int u = 0; u < comidadama.length; u++) {
                        comidadama4[u].setIcon(vazio);
                        comeudama = false;
                    }

                }

                if ((i3 < i) && (j3 > j)) {

                    for (int u = 0; u < comidadama.length; u++) {
                        comidadama3[u].setIcon(vazio);
                        comeudama = false;
                    }

                }
                if ((i3 > i) && (j3 < j)) {
                    for (int u = 0; u < comidadama.length; u++) {
                        comidadama2[u].setIcon(vazio);
                        comeudama = false;
                    }

                }

            }

            if (comeu) {
                if ((i2 < i) && (j2 == j)) {

                    comebtn[0].setIcon(vazio);
                    comebtn[5].setIcon(vazio);

                    comeu = false;

                }
                if ((i2 > i) && (j2 == j)) {

                    comebtn2[0].setIcon(vazio);
                    comebtn2[5].setIcon(vazio);

                    comeu = false;

                }
                if (comecome) {
                    comebtn[0].setIcon(vazio);
                    comebtn[5].setIcon(vazio);
                    comebtn[4].setIcon(vazio);
                    comeu = false;

                    comecome = false;
                }

                if (comecome2) {
                    comebtn2[0].setIcon(vazio);
                    comebtn2[5].setIcon(vazio);
                    comebtn2[4].setIcon(vazio);
                    comeu = false;

                    comecome2 = false;
                }

                if ((i2 < i) && (j2 < j)) {
                    for (int u = 0; u < tm[1]; u++) {
                        comebtn[u].setIcon(vazio);
                    }
                    comeu = false;

                }

                if ((i2 > i) && (j2 < j)) {
                    for (int u = 0; u < tm[0]; u++) {
                        comebtn2[u].setIcon(vazio);
                    }
                    comeu = false;
                    podecomer = false;

                }

                if ((i2 < i) && (j2 > j)) {
                    for (int u = 0; u < tm[2]; u++) {
                        comebtn4[u].setIcon(vazio);
                    }
                    comeu = false;

                }

                if ((i2 > i) && (j2 > j)) {
                    for (int u = 0; u < tm[3]; u++) {
                        comebtn3[u].setIcon(vazio);
                    }
                    comeu = false;

                }

            }

        }
    }

    static public void podecomer(int i, int j) {
 int cont = 1;
        int cont2;
        int a, b;
        if ((i - cont >= 0) && (j + cont <= 7) && ((i - cont - 1) >= 0) && ((j + cont + 1) <= 7)) {
            if ((button[i][j].getIcon() == Preto) && ((button[i - cont][j + cont].getIcon() == branco)||(button[i - cont][j + cont].getIcon() == damabranca)) && (button[i - cont - 1][j + cont + 1].getIcon() == vazio)) {
                podecomer = true;

            }
        }
        if ((i + cont <= 7) && (j + cont <= 7) && ((i + cont + 1) <= 7) && ((j + cont + 1) <= 7)) {

            if ((button[i][j].getIcon() == Preto) && ((button[i + cont][j + cont].getIcon() == branco)||(button[i + cont][j + cont].getIcon() == damabranca)) && (button[i + cont + 1][j + cont + 1].getIcon() == vazio)) {
                podecomer = true;

            }
        }
        if ((i + cont <= 7) && (j - cont >= 0) && ((i + cont + 1) <= 7) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == Preto) && ((button[i + cont][j - cont].getIcon() == branco)||(button[i + cont][j - cont].getIcon() == damabranca)) && (button[i + cont + 1][j - cont - 1].getIcon() == vazio)) {
                podecomer = true;

            }
        }
        if ((i - cont >= 0) && (j - cont >= 0) && ((i - cont - 1) >= 0) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == Preto) && ((button[i - cont][j - cont].getIcon() == branco)||(button[i - cont][j - cont].getIcon() == damabranca)) && (button[i - cont - 1][j - cont - 1].getIcon() == vazio)) {

                podecomer = true;
            }
        }

        //comer branco
        if ((i - cont >= 0) && (j + cont <= 7) && ((i - cont - 1) >= 0) && ((j + cont + 1) <= 7)) {

            if ((button[i][j].getIcon() == branco) && ((button[i - cont][j + cont].getIcon() == Preto)||(button[i - cont][j + cont].getIcon() == damapreta)) && (button[i - cont - 1][j + cont + 1].getIcon() == vazio)) {
                podecomer = true;
            }
        }

        if ((i + cont <= 7) && (j + cont <= 7) && ((i + cont + 1) <= 7) && ((j + cont + 1) <= 7)) {

            if ((button[i][j].getIcon() == branco) && ((button[i + cont][j + cont].getIcon() == Preto)||(button[i + cont][j + cont].getIcon() == damapreta)) && (button[i + cont + 1][j + cont + 1].getIcon() == vazio)) {
                podecomer = true;

            }
        }
        if ((i - cont >= 0) && (j - cont >= 0) && ((i - cont - 1) >= 0) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == branco) && ((button[i - cont][j - cont].getIcon() == Preto)||(button[i - cont][j - cont].getIcon() == damapreta)) && (button[i - cont - 1][j - cont - 1].getIcon() == vazio)) {

                podecomer = true;
            }
        }
        if ((i + cont <= 7) && (j - cont >= 0) && ((i + cont + 1) <= 7) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == branco) && ((button[i + cont][j - cont].getIcon() == Preto)||(button[i + cont][j - cont].getIcon() == damapreta)) && (button[i + cont + 1][j - cont - 1].getIcon() == vazio)) {
                podecomer = true;
            }
        }
    
    }

    static public void comer(int i, int j) {
        int cont = 1;
        int cont2;
        int a, b;

        if ((i - cont >= 0) && (j + cont <= 7) && ((i - cont - 1) >= 0) && ((j + cont + 1) <= 7)) {
            if ((button[i][j].getIcon() == Preto) && ((button[i - cont][j + cont].getIcon() == branco)||(button[i - cont][j + cont].getIcon() == damabranca)) && (button[i - cont - 1][j + cont + 1].getIcon() == vazio)) {
                button[i - cont - 1][j + cont + 1].setIcon(verde);
                comeu = true;
                tm[0] = 1;
                comebtn2[0] = button[i - cont][j + cont];

                if ((i - cont - 2 >= 0) && (j + cont + 2 <= 7) && ((i - cont - 3) >= 0) && ((j + cont + 3) <= 7)) {
                    if (((button[i - cont - 2][j + cont + 2].getIcon() == branco)||(button[i - cont - 2][j + cont + 2].getIcon() == damabranca)) && (button[i - cont - 3][j + cont + 3].getIcon() == vazio)) {
                        button[i - cont - 3][j + cont + 3].setIcon(verde);
                        tm[0] = 2;
                        comebtn2[1] = button[i - cont - 2][j + cont + 2];
                        button[i - cont - 1][j + cont + 1].setIcon(verde2);
                        if ((i - cont - 4 >= 0) && (j + cont + 4 <= 7) && ((i - cont - 5) >= 0) && ((j + cont + 5) <= 7)) {
                            if (((button[i - cont - 4][j + cont + 4].getIcon() == branco)||(button[i - cont - 4][j + cont + 4].getIcon() == damabranca)) && (button[i - cont - 5][j + cont + 5].getIcon() == vazio)) {
                                button[i - cont - 5][j + cont + 5].setIcon(verde);
                                tm[0] = 3;
                                comebtn2[2] = button[i - cont - 4][j + cont + 4];
                                button[i - cont - 3][j + cont + 3].setIcon(verde2);
                            }
                        }

                    }
                }

            }
        }

        if ((i + cont <= 7) && (j + cont <= 7) && ((i + cont + 1) <= 7) && ((j + cont + 1) <= 7)) {

            if ((button[i][j].getIcon() == Preto) && ((button[i + cont][j + cont].getIcon() == branco)||(button[i + cont][j + cont].getIcon() == damabranca)) && (button[i + cont + 1][j + cont + 1].getIcon() == vazio)) {
                button[i + cont + 1][j + cont + 1].setIcon(verde);
                comeu = true;
                tm[1] = 1;
                comebtn[0] = button[i + cont][j + cont];

                ///////////////////
                if ((i + cont + 2 <= 7) && (j + cont + 2 <= 7) && ((i + cont + 3) <= 7) && ((j + cont + 3) <= 7)) {

                    if (((button[i + cont + 2][j + cont + 2].getIcon() == branco)||(button[i + cont + 2][j + cont + 2].getIcon() == damabranca))&& (button[i + cont + 3][j + cont + 3].getIcon() == vazio)) {
                        button[i + cont + 3][j + cont + 3].setIcon(verde);
                        tm[1] = 2;
                        comebtn[1] = button[i + cont + 2][j + cont + 2];
                        button[i + cont + 1][j + cont + 1].setIcon(verde2);
                        if ((i + cont + 4 <= 7) && (j + cont + 4 <= 7) && ((i + cont + 5) <= 7) && ((j + cont + 5) <= 7)) {

                            if (((button[i + cont + 4][j + cont + 4].getIcon() == branco)||(button[i + cont + 4][j + cont + 4].getIcon() == damabranca)) && (button[i + cont + 5][j + cont + 5].getIcon() == vazio)) {
                                button[i + cont + 5][j + cont + 5].setIcon(verde);
                                tm[1] = 3;
                                comebtn[2] = button[i + cont + 4][j + cont + 4];

                                button[i + cont + 3][j + cont + 3].setIcon(verde2);
                            }

                        }

                    }

                }
            }

        }

        //Diagonal 2 - preto
        if ((i + cont <= 7) && (j - cont >= 0) && ((i + cont + 1) <= 7) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == Preto) && ((button[i + cont][j - cont].getIcon() == branco)||(button[i + cont][j - cont].getIcon() == damabranca)) && (button[i + cont + 1][j - cont - 1].getIcon() == vazio)) {
                button[i + cont + 1][j - cont - 1].setIcon(verde);
                comeu = true;
                tm[2] = 1;
                comebtn4[0] = button[i + cont][j - cont];
                //comida dupla zigzag

                //
                if ((i + cont + 2 <= 7) && (j - cont - 2 >= 0) && ((i + cont + 3) <= 7) && ((j - cont - 3) >= 0)) {

                    if (((button[i + cont + 2][j - cont - 2].getIcon() == branco)||(button[i + cont + 2][j - cont - 2].getIcon() == damabranca)) && (button[i + cont + 3][j - cont - 3].getIcon() == vazio)) {
                        button[i + cont + 3][j - cont - 3].setIcon(verde);
                        tm[2] = 2;
                        comebtn4[1] = button[i + cont + 2][j - cont - 2];
                        button[i + cont + 1][j - cont - 1].setIcon(verde2);
                        if ((i + cont + 4 <= 7) && (j - cont - 4 >= 0) && ((i + cont + 5) <= 7) && ((j - cont - 5) >= 0)) {

                            if (((button[i + cont + 4][j - cont - 4].getIcon() == branco)||(button[i + cont + 4][j - cont - 4].getIcon() == damabranca)) && (button[i + cont + 5][j - cont - 5].getIcon() == vazio)) {
                                button[i + cont + 5][j - cont - 5].setIcon(verde);
                                tm[2] = 3;
                                comebtn4[2] = button[i + cont + 4][j - cont - 4];

                                button[i + cont + 3][j - cont - 3].setIcon(verde2);
                            }

                        }

                    }

                }
            }

        }

        if ((i - cont >= 0) && (j - cont >= 0) && ((i - cont - 1) >= 0) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == Preto) && ((button[i - cont][j - cont].getIcon() == branco)||(button[i - cont][j - cont].getIcon() == damabranca)) && (button[i - cont - 1][j - cont - 1].getIcon() == vazio)) {
                button[i - cont - 1][j - cont - 1].setIcon(verde);
                comeu = true;
                tm[3] = 1;
                comebtn3[0] = button[i - cont][j - cont];
                if ((i - cont - 2 >= 0) && (j - cont - 2 >= 0) && ((i - cont - 3) >= 0) && ((j - cont - 3) >= 0)) {

                    if (((button[i - cont - 2][j - cont - 2].getIcon() == branco)||(button[i - cont - 2][j - cont -2].getIcon() == damabranca)) && (button[i - cont - 3][j - cont - 3].getIcon() == vazio)) {
                        button[i - cont - 3][j - cont - 3].setIcon(verde);
                        tm[3] = 2;
                        comebtn3[1] = button[i - cont - 2][j - cont - 2];
                        button[i - cont - 1][j - cont - 1].setIcon(verde2);
                        if ((i - cont - 4 >= 0) && (j - cont - 4 >= 0) && ((i - cont - 5) >= 0) && ((j - cont - 5) >= 0)) {
                            if (((button[i - cont - 4][j - cont - 4].getIcon() == branco)||(button[i - cont - 4][j - cont - 4].getIcon() == damabranca)) && (button[i - cont - 5][j - cont - 5].getIcon() == vazio)) {
                                button[i - cont - 5][j - cont - 5].setIcon(verde);
                                tm[3] = 3;
                                comebtn3[2] = button[i - cont - 4][j - cont - 4];
                                button[i - cont - 3][j - cont - 3].setIcon(verde2);

                            }
                        }
                    }
                }

            }
        }

        //comer branco
        if ((i - cont >= 0) && (j + cont <= 7) && ((i - cont - 1) >= 0) && ((j + cont + 1) <= 7)) {
            if ((button[i][j].getIcon() == branco) && ((button[i - cont][j + cont].getIcon() == Preto)||(button[i - cont][j + cont].getIcon() == damapreta)) && (button[i - cont - 1][j + cont + 1].getIcon() == vazio)) {
                button[i - cont - 1][j + cont + 1].setIcon(verde);
                comeu = true;
                tm[0] = 1;
                comebtn2[0] = button[i - cont][j + cont];
                if ((i - cont - 2 >= 0) && (j + cont + 2 <= 7) && ((i - cont - 3) >= 0) && ((j + cont + 3) <= 7)) {
                    if (((button[i - cont - 2][j + cont + 2].getIcon() == Preto)||(button[i - cont - 2][j + cont + 2].getIcon() == damapreta)) && (button[i - cont - 3][j + cont + 3].getIcon() == vazio)) {
                        button[i - cont - 3][j + cont + 3].setIcon(verde);
                        tm[0] = 2;
                        comebtn2[1] = button[i - cont - 2][j + cont + 2];
                        button[i - cont - 1][j + cont + 1].setIcon(verde2);
                        if ((i - cont - 4 >= 0) && (j + cont + 4 <= 7) && ((i - cont - 5) >= 0) && ((j + cont + 5) <= 7)) {
                            if (((button[i - cont - 4][j + cont + 4].getIcon() == Preto)||(button[i - cont - 4][j + cont + 4].getIcon() == damapreta)) && (button[i - cont - 5][j + cont + 5].getIcon() == vazio)) {
                                button[i - cont - 5][j + cont + 5].setIcon(verde);
                                tm[0] = 3;
                                comebtn2[2] = button[i - cont - 4][j + cont + 4];
                                button[i - cont - 3][j + cont + 3].setIcon(verde2);
                            }
                        }

                    }
                }

            }
        }

        if ((i + cont <= 7) && (j + cont <= 7) && ((i + cont + 1) <= 7) && ((j + cont + 1) <= 7)) {

            if ((button[i][j].getIcon() == branco) && ((button[i + cont][j + cont].getIcon() == Preto)||(button[i + cont][j + cont].getIcon() == damapreta)) && (button[i + cont + 1][j + cont + 1].getIcon() == vazio)) {
                button[i + cont + 1][j + cont + 1].setIcon(verde);
                comeu = true;
                tm[1] = 1;
                comebtn[0] = button[i + cont][j + cont];

                if ((i + cont + 2 <= 7) && (j + cont + 2 <= 7) && ((i + cont + 3) <= 7) && ((j + cont + 3) <= 7)) {

                    if (((button[i + cont + 2][j + cont + 2].getIcon() == Preto)||(button[i + cont + 2][j + cont + 2].getIcon() == damapreta)) && (button[i + cont + 3][j + cont + 3].getIcon() == vazio)) {
                        button[i + cont + 3][j + cont + 3].setIcon(verde);
                        tm[1] = 2;
                        comebtn[1] = button[i + cont + 2][j + cont + 2];
                        button[i + cont + 1][j + cont + 1].setIcon(verde2);
                        if ((i + cont + 4 <= 7) && (j + cont + 4 <= 7) && ((i + cont + 5) <= 7) && ((j + cont + 5) <= 7)) {

                            if (((button[i + cont + 4][j + cont + 4].getIcon() == Preto)||(button[i + cont + 4][j + cont + 4].getIcon() == damapreta)) && (button[i + cont + 5][j + cont + 5].getIcon() == vazio)) {
                                button[i + cont + 5][j + cont + 5].setIcon(verde);
                                tm[1] = 3;
                                comebtn[2] = button[i + cont + 4][j + cont + 4];
                                button[i + cont + 3][j + cont + 3].setIcon(verde2);
                            }

                        }

                    }

                }
            }

        }

        if ((i + cont <= 7) && (j - cont >= 0) && ((i + cont + 1) <= 7) && ((j - cont - 1) >= 0)) {

            if ((button[i][j].getIcon() == branco) && ((button[i + cont][j - cont].getIcon() == Preto)||(button[i + cont][j - cont].getIcon() == damapreta)) && (button[i + cont + 1][j - cont - 1].getIcon() == vazio)) {
                button[i + cont + 1][j - cont - 1].setIcon(verde);
                comeu = true;
                tm[2] = 1;
                comebtn4[0] = button[i + cont][j - cont];

                if ((i + cont + 2 <= 7) && (j - cont - 2 >= 0) && ((i + cont + 3) <= 7) && ((j - cont - 3) >= 0)) {

                    if (((button[i + cont + 2][j - cont - 2].getIcon() == Preto)||(button[i + cont + 2][j - cont - 2].getIcon() == damapreta)) && (button[i + cont + 3][j - cont - 3].getIcon() == vazio)) {
                        button[i + cont + 3][j - cont - 3].setIcon(verde);
                        tm[2] = 2;
                        comebtn4[1] = button[i + cont + 2][j - cont - 2];
                        button[i + cont + 1][j - cont - 1].setIcon(verde2);
                        if ((i + cont + 4 <= 7) && (j - cont - 4 >= 0) && ((i + cont + 5) <= 7) && ((j - cont - 5) >= 0)) {

                            if (((button[i + cont + 4][j - cont - 4].getIcon() == Preto)||(button[i + cont + 4][j - cont - 4].getIcon() == damapreta)) && (button[i + cont + 5][j - cont - 5].getIcon() == vazio)) {
                                button[i + cont + 5][j - cont - 5].setIcon(verde);
                                tm[2] = 3;
                                comebtn4[2] = button[i + cont + 4][j - cont - 4];

                                button[i + cont + 3][j - cont - 3].setIcon(verde2);
                            }

                        }

                    }

                }
            }

        }

        if ((i - cont >= 0) && (j - cont >= 0) && ((i - cont - 1) >= 0) && ((j - cont - 1) >= 0)) {
 
            if ((button[i][j].getIcon() == branco) && ((button[i - cont][j - cont].getIcon() == Preto)||(button[i - cont][j - cont].getIcon() == damapreta)) && (button[i - cont - 1][j - cont - 1].getIcon() == vazio)) {
                button[i - cont - 1][j - cont - 1].setIcon(verde);
                comeu = true;
                tm[3] = 1;
                comebtn3[0] = button[i - cont][j - cont];
                if ((i - cont - 2 >= 0) && (j - cont - 2 >= 0) && ((i - cont - 3) >= 0) && ((j - cont - 3) >= 0)) {

                    if (((button[i - cont - 2][j - cont - 2].getIcon() == Preto)||(button[i - cont - 2][j - cont - 2].getIcon() == damapreta)) && (button[i - cont - 3][j - cont - 3].getIcon() == vazio)) {
                        button[i - cont - 3][j - cont - 3].setIcon(verde);
                        tm[3] = 2;
                        comebtn3[1] = button[i - cont - 2][j - cont - 2];
                        button[i - cont - 1][j - cont - 1].setIcon(verde2);
                        if ((i - cont - 4 >= 0) && (j - cont - 4 >= 0) && ((i - cont - 5) >= 0) && ((j - cont - 5) >= 0)) {
                            if (((button[i - cont - 4][j - cont - 4].getIcon() == Preto)||(button[i - cont - 4][j - cont - 4].getIcon() == damapreta)) && (button[i - cont - 5][j - cont - 5].getIcon() == vazio)) {
                                button[i - cont - 5][j - cont - 5].setIcon(verde);
                                tm[3] = 3;
                                comebtn3[2] = button[i - cont - 4][j - cont - 4];
                                button[i - cont - 3][j - cont - 3].setIcon(verde2);
                            }
                        }
                    }
                }

            }

        }
    }

    static public void vitoria() {
        contapreto2=0;
        contabranco2=0;
        contadama22=0;
        contadama1=0;
        for (int h = 0; h < 8; h++) {
            for (int h2 = 0; h2 < 8; h2++) {
                if (button[h][h2].getIcon() == Preto) {
                    contapreto2++;
                }
                if (button[h][h2].getIcon() == branco) {
                    contabranco2++;
                }
                if (button[h][h2].getIcon() == damapreta) {
                    contadama1++;
                }
                if (button[h][h2].getIcon() == damabranca) {
                    contadama22++;
                }
            }
        }
        if ((contadama1 == 0) && (contapreto2 == 0)) { //vitoria 

            JOptionPane.showMessageDialog(null, "Vitoria Branco");
            System.exit(0);
        }
        if (((contadama22 == 0) && (contabranco2 == 0))) {

            JOptionPane.showMessageDialog(null, "Vitoria Preto");
            System.exit(0);
        }

    }

    static public void btnvazio() {
        for (int a = 0; a < 8; a++) {
            for (int b = 0; b < 8; b++) {
                if ((button[a][b].getIcon() == verde) || (button[a][b].getIcon() == verde2)) {
                    button[a][b].setIcon(vazio);
                }

            }
        }
    }

}
