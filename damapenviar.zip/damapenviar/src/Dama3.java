/*
autores:
 */

import java.awt.Component;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.JFrame;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Dama3 {


    static Metodhs mtd = new Metodhs();
    static JLabel label = new JLabel();
    static JLabel imgLado = new JLabel();
    static JButton[][] button = new JButton[8][8];
    static Icon vazio = new ImageIcon("src\\img\\fundo escuro.png");
    static Icon Preto = new ImageIcon("src\\img\\preto peça.png");
    static Icon white = new ImageIcon("src\\img\\fundo claro.png");
    static Icon branco = new ImageIcon("src\\img\\branca peça.png");
    static Icon verde = new ImageIcon("src\\img\\verdinho.png");
    static Icon verde2 = new ImageIcon("src\\img\\verdinho2.png");
    static Icon damabranca = new ImageIcon("src\\img\\dama branca.png");
    static Icon damapreta = new ImageIcon("src\\img\\dama preto.png");
    static GridBagConstraints gbc;
    private static final Insets insets = new Insets(0, 0, 0, 0);

    public static void main(final String args[]) {

        final JFrame frame = new JFrame("Jogo de Dama");
        frame.setLayout(new GridBagLayout());

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                button[i][j] = new JButton(" ");
                addComponent(frame, button[i][j], i, j, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH);
            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {
                    button[i][j].setIcon(vazio);

                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(vazio);

                } else {
                    button[i][j].setIcon(white);
                }

            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 3; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {

                    button[i][j].setIcon(Preto);
                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(Preto);
                }
            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 5; j < 8; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {
                    button[i][j].setIcon(branco);
                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(branco);
                }

            }
        }
      
        //ações dos botoes:
        button[1][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 0);

            }
        });

        button[3][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 0);

            }
        });

        button[5][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 0);

            }
        });

        button[7][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 0);

            }
        });

        button[0][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 1);

            }
        });

        button[2][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 1);

            }
        });

        button[4][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(4, 1);

            }
        });

        button[6][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 1);

            }
        });

        button[1][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 2);

            }
        });

        button[3][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 2);

            }
        });

        button[5][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 2);
            }
        });

        button[7][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 2);

            }
        });

        button[0][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 3);

            }
        });

        button[2][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 3);

            }
        });

        button[4][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Metodhs.changecolor(4, 3);

            }
        });

        button[6][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 3);

            }
        });

        button[1][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 4);

            }
        });

        button[3][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 4);

            }
        });

        button[5][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 4);

            }
        });

        button[7][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 4);

            }
        });

        button[0][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 5);

            }
        });

        button[2][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 5);

            }
        });

        button[4][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(4, 5);

            }
        });

        button[6][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 5);

            }
        });

        button[1][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 6);

            }
        });

        button[3][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 6);

            }
        });

        button[5][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 6);

            }
        });

        button[7][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 6);

            }
        });

        button[0][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 7);

            }
        });

        button[2][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 7);

            }
        });

        button[4][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(4, 7);

            }
        });

        button[6][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 7);

            }
        });

        //barra do menu
        JMenuBar barra = new JMenuBar();
        frame.setJMenuBar(barra);

        //opção arquivo
        JMenu arquivo = new JMenu("Opção");
        barra.add(arquivo);

        //opção de resetar o tabuleiro
        JMenuItem resetar = new JMenuItem("Resetar");
        resetar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                reset();

            }
        });

        arquivo.add(resetar);

        //opção de sair
        JMenuItem sair = new JMenuItem("Sair");
        sair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                System.exit(0);
            }
        });

        arquivo.add(sair);

        //opção help
        JMenu menu = new JMenu("Ajuda");
        barra.add(menu);

        //opçaõ sobre as regras oficias da dama
        JMenuItem regras = new JMenuItem("Regras");
        try {
            regras.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    //abrir arquivo em pdf
                    File file = new File("src\\pdf\\regras oficias.pdf");

                    if (file.exists()) {
                        if (Desktop.isDesktopSupported()) {
                            try {
                                Desktop.getDesktop().open(file);
                            } catch (IOException ex) {
                                Logger.getLogger(Dama3.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

        menu.add(regras);
        
        JMenuItem teste = new JMenuItem("Testes");
        try 
        {
            teste.addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent evt) 
                {   
                    //abrir qualquer link no navegar padrão do desktop
                    Desktop d = Desktop.getDesktop(); 
                    try
                    { 
                        d.browse(new URI("https://www.canva.com/design/DAFjqTe63uc/yC1r_Sb4z3GvhZ93GToYQA/edit?utm_content=DAFjqTe63uc&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton")); 
                    } 
                    catch(Exception e)
                    { 
                        e.printStackTrace(); 
                    }
                }
            });

        } catch (Exception e) 
        {
            e.printStackTrace();
        }
        menu.add(teste);

        //opção sobre
        JMenu sobre = new JMenu("Criação");
        barra.add(sobre);

        //opção sobre os autores e criação
        JMenuItem auto = new JMenuItem("Autores");
        try {
            auto.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    //abrir arquivo em pdf
                    File file = new File("src\\pdf\\dama autores.pdf");

                    if (file.exists()) {
                        if (Desktop.isDesktopSupported()) {
                            try {
                                Desktop.getDesktop().open(file);
                            } catch (IOException ex) {
                                Logger.getLogger(Dama3.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

        sobre.add(auto);

        //desing do tabuleiro 
        frame.setSize(740, 740);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

        ImageIcon icone = new ImageIcon("src\\img\\tabu.jpeg");
        frame.setIconImage(icone.getImage());
    }

    private static void addComponent(Container container, Component component, int gridx, int gridy, int gridwidth, int gridheight, int anchor, int fill) {
        gbc = new GridBagConstraints(gridx, gridy, gridwidth, gridheight, 1, 1, anchor, fill, insets, 1, 1);
        container.add(component, gbc);
    }

    static public void reset() {

        mtd.vez = 0;

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {
                    button[i][j].setIcon(vazio);

                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(vazio);

                } else {
                    button[i][j].setIcon(white);
                }

            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 3; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {

                    button[i][j].setIcon(Preto);
                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(Preto);
                }
            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 5; j < 8; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {
                    button[i][j].setIcon(branco);
                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(branco);
                }

            }
        }

    }

}
